#pragma once
#include "ryanWFunctions.h"



// Returns true if c is one of R, Y, B, G.
bool isValidColor(char c);

// Skip plays again
bool skipCard(bool playerTurn);

//+2 other player draws 2 and skips turn
bool drawTwoCard(Card opponentHand[], int& opponentSize, int maxHandSize, bool playerTurn);

// Wild player chosses topcards color
bool wildCard(Card& topCard, char chosenColor, bool playerTurn);

// +4 other player draws 4, played player chooses color and plays again
bool drawFourCard(Card opponentHand[], int& opponentSize, int maxHandSize, Card& topCard, char chosenColor, bool playerTurn); #pragma once
