#pragma once
#include <string>;

using namespace std;

struct Card {

	char cardType; // if its 1,2,3,4 etc change the marker in this class to what you use

	char cardColor;// the color of the card use caps and only the first letter

};

bool playCard(Card otherPlayerHand[], int numSize, Card playedCard, Card& topCard, bool playerTurn);// returns the players turn

bool checkIfViableCard(Card playerCard, Card topCard); // makes sure the card can be played

Card drawCard(); //returns the drawn card

bool start(Card playerHand[], Card otherPlayerHand[]); // returns the players turn. true == player 1 | false == player 2

void makeValidStart(Card& topCard);

bool checkIfCardPlayable(Card playerHand[], Card otherPlayerHand[], int size, int& otherSize, int maxSize, Card& topCard, bool playerTurn);

bool canPlay(Card playerHand[], Card topCard, int size);