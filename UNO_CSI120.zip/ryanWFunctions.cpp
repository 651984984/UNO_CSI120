#include <string>;
#include <iostream>
#include <cstdlib>;
#include <ctime>
#include "ryanTFunctions.h";

using namespace std;


const char plus2Marker = '-';

const char plus4Marker = '+';

const char skipMarker = 'S';

const char wildMarker = 'W';

const char deck[] = { '1','2','3','4','5','6','7','8','9','0',skipMarker,plus2Marker,plus4Marker, wildMarker };

const char colors[] = { 'R','Y','B','G' };



bool playCard(Card otherPlayerHand[], int& numSize, int maxSize, Card playedCard, Card& topCard, bool playerTurn)
{
	topCard = playedCard;
	switch (playedCard.cardType)
	{
	case skipMarker:
		return skipCard(playerTurn);
		break;
	case plus2Marker:
		return drawTwoCard(otherPlayerHand, numSize, maxSize, playerTurn);
		break;

	case plus4Marker:
		char chosenColor = ' ';
		do
		{
			cout << "Enter the first letter of the color that you want\n";
			cin >> chosenColor;
			chosenColor = (char)toupper(chosenColor);
		} while (!isValidColor(chosenColor));
		return drawFourCard(otherPlayerHand, numSize, maxSize, topCard, chosenColor, playerTurn);
		break; // add the plus 4 function

	case wildMarker:
		char chosenColor = ' ';
		do
		{
			cout << "Enter the first letter of the color that you want\n";
			cin >> chosenColor;
			chosenColor = (char)toupper(chosenColor);
		} while (!isValidColor(chosenColor));
		wildCard(topCard, chosenColor, playerTurn);
		break; //add what needs to happen if its wild
	}
	return !playerTurn;
}

bool checkIfViableCard(Card playerCard, Card topCard)
{
	return playerCard.cardType == topCard.cardType || playerCard.cardColor == topCard.cardColor; //seeing if its playable
}

Card drawCard()
{
	int deckSize = 13;

	int colorSize = 4;

	Card newCard;

	newCard.cardType = deck[rand() % deckSize];

	newCard.cardColor = deck[rand() % colorSize];

	return newCard;
}

bool start(Card playerHand[], Card otherPlayerHand[])
{
	int startingHandSize = 7;

	srand(time(NULL));

	for (int i = 0; i < startingHandSize; i++)
	{
		playerHand[i] = drawCard();

		otherPlayerHand[i] = drawCard();
	}

	return rand() % 2 == 1; //randomly picks a players turn
}

void makeValidStart(Card& topCard)
{
	while (topCard.cardType == skipMarker || topCard.cardType == wildMarker || topCard.cardType == plus2Marker || topCard.cardType == plus4Marker)
		topCard = drawCard();
}

bool checkIfCardPlayable(Card playerHand[], Card otherPlayerHand[], int size, int& otherSize, int maxSize, Card& topCard, bool playerTurn)
{
	int num = -1;
	do
	{
		cout << "Enter the index of the card that you want to play(integer Starting from 0)\n";
		cin >> num;
	} while (num >= size ||  num < 0 || checkIfViableCard(playerHand[num], topCard));
	return playCard(otherPlayerHand, otherSize, maxSize, playerHand[num], topCard, playerTurn);
}

bool canPlay(Card playerHand[], Card topCard, int size)
{
	for (int i = 0; i < size; i++)
	{
		if (checkIfViableCard(playerHand[i], topCard))
			return true;
	}
	return false;
}