#include <iostream>
#include <string>
#include "ryanWFunctions.h"
#include "ryanTFunctions.h"
#include "ryanTCardArt.h"
#include <fstream>


using namespace std;

int main()
{
	//player initilization
	Card playerOneHand[50];
	Card playerTwoHand[50];

	int playerOneSize = 7;
	int playerTwoSize = 7;

	int maxHandSize = 50;

	bool playerTurn = start(playerOneHand, playerTwoHand);

	string playerOneName;
	string playerTwoName;

	cout << "Player One Please Enter Your Name:\n";
	cin >> playerOneName;

	cout << "Player Two Please Enter Your Name:\n";
	cin >> playerOneName;

	//Getting the top card
	Card topCard;
	makeValidStart(topCard);

	while (playerOneSize <= 0 || playerTwoSize <= 0)
	{
		break;

		if (playerTurn)
		{
			cout << playerOneName << "'s turn\n";
			if (canPlay(playerOneHand, topCard, playerOneSize))
				playerTurn = checkIfCardPlayable(playerOneHand, playerTwoHand, playerOneSize, playerTwoSize, maxHandSize, topCard, playerTurn);
			else
			{
				
			}
		}
		else
		{
			cout << playerTwoName << "'s turn\n";
		}
		
		

	}

	return 0;
}