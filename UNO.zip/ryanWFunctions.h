#pragma once
#include <string>;

using namespace std;

struct Card;

bool playCard(Card otherPlayerHand[], int numSize, Card playedCard, Card& topCard, bool playerTurn);// returns the players turn

bool checkIfViableCard(Card playerCard, Card topCard); // makes sure the card can be played

Card drawCard(); //returns the drawn card

bool start(Card playerHand[], Card otherPlayerHand[]); // returns the players turn. true == player 1 | false == player 2