#include "ryanTFunctions.h"

using namespace std;

// Draws up to count cards into the hand without running past the array.
static void drawCards(Card hand[], int& handSize, int maxHandSize, int count)
{
	for (int i = 0; i < count && handSize < maxHandSize; i++)
	{
		hand[handSize] = drawCard();
		handSize++;
	}
}

bool isValidColor(char c)
{
	return c == 'R' || c == 'Y' || c == 'B' || c == 'G';
}

bool skipCard(bool playerTurn)
{
	return playerTurn;
}

bool drawTwoCard(Card opponentHand[], int& opponentSize, int maxHandSize, bool playerTurn)
{
	drawCards(opponentHand, opponentSize, maxHandSize, 2);

	return playerTurn; // opponent also loses their turn
}

bool wildCard(Card& topCard, char chosenColor, bool playerTurn)
{
	if (isValidColor(chosenColor))
	{
		topCard.cardColor = chosenColor;
	}

	return !playerTurn; // wild is a normal turn, so it passes to the other player
}

bool drawFourCard(Card opponentHand[], int& opponentSize, int maxHandSize, Card& topCard, char chosenColor, bool playerTurn)
{
	drawCards(opponentHand, opponentSize, maxHandSize, 4);

	if (isValidColor(chosenColor))
	{
		topCard.cardColor = chosenColor;
	}

	return playerTurn; // opponent also loses their turn
}