#include <string>;
#include <cstdlib>;
#include <ctime>

using namespace std;


const char plus2Marker = '-';

const char plus4Marker = '+';

const char skipMarker = 'S';

const char wildMarker = 'W';

const char deck[] = { '1','2','3','4','5','6','7','8','9','0',skipMarker,plus2Marker,plus4Marker, wildMarker};

const char colors[] = {'R','Y','B','G'};

struct Card {

	char cardType; // if its 1,2,3,4 etc change the marker in this class to what you use

	char cardColor;// the color of the card use caps and only the first letter

};

bool playCard(Card otherPlayerHand[], int numSize, Card playedCard, Card& topCard, bool playerTurn)
{
	topCard = playedCard;
	switch (playedCard.cardType)
	{
	case skipMarker: 
		return playerTurn; // replace this with skip
		break;
	case plus2Marker:
		break; //add the plus 2 function

	case plus4Marker:
		break; // add the plus 4 function
	
	case wildMarker:
		break; //add what needs to happen if its wild
	}
	return !playerTurn;
}

bool checkIfViableCard(Card playerCard, Card topCard)
{
	return playerCard.cardType == topCard.cardType || playerCard.cardColor == topCard.cardColor; //seeing if its playable
}

Card drawCard()
{
	int deckSize = 13;

	int colorSize = 4;

	Card newCard;

	newCard.cardType = deck[rand() % deckSize];

	newCard.cardColor = deck[rand() % colorSize];
	
	return newCard;
}

bool start(Card playerHand[], Card otherPlayerHand[])
{
	int startingHandSize = 7;

	srand(time(NULL));

	for (int i = 0; i < startingHandSize; i++)
	{
		playerHand[i] = drawCard();

		otherPlayerHand[i] = drawCard();
	}

	return rand() % 2 == 1; //randomly picks a players turn
}